# gltm_experiments
This repo contains experiments described in the paper "General Linear Threshold Model with Application to Influence Maximization" [(Kagan et al., 2024)](https://arxiv.org/abs/2411.09100).
